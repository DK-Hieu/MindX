SELECT top 1 * FROM msdb.dbo.sysmail_allitems order by mailitem_id desc;

USE msdb
GO
EXEC sp_send_dbmail @profile_name='gmail1',
@recipients='tuanphanhn92@gmail.com',
@subject='Test message',
@body='This is the body of the test message.
Congrates Database Mail Received By you Successfully.'
