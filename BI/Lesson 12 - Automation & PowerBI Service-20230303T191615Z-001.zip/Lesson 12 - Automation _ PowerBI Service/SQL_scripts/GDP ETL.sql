﻿use D4E

create table new_GDP
(country varchar(50)
, year varchar(4)
, currency varchar(3)
, gdp float)

--thêm những dòng dữ liệu mới ở bảng GDP vào bảng new_GDP
insert into new_GDP (country, year, currency, gdp)
select 
	GDP.country
	, GDP.year
	, GDP.currency
	, GDP.gdp
from DWH1.Test.dbo.GDP as GDP
left outer join new_GDP 
on GDP.country = new_GDP.country and GDP.year = new_GDP.year
where new_GDP.country is null --điều kiện này để lọc ra những dòng dữ liệu mà chỉ có ở bảng GDP (nghĩa là dữ liệu mới) và insert vào bảng new_GDP

--Thêm 1 dòng dữ liệu vào bảng GDP
insert into Test.dbo.GDP
values('Vietnam', '2016', 'USD', 205276000000)

--chạy lại code insert dữ liệu vào bảng new_GDP bên trên, sẽ có 1 dòng dữ liệu được thêm mới vào bảng new_GDP

--query dữ liệu bảng new_GDP để kiểm tra dòng dữ liệu mới
select * from new_GDP where country = 'vietnam'
select count(1) from new_GDP
select count(1) from TEST.Test.dbo.GDP

--giờ ta cần đặt lịch để chạy đoạn code thêm mới dữ liệu bên trên