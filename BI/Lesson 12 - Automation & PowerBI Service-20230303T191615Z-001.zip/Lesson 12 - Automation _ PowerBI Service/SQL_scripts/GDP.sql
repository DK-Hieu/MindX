--choose the database on your local machine to work with
use Test

--create GDP table
create table GDP
(country varchar(50)
, year varchar(4)
, currency varchar(3)
, gdp float)

--insert data into GDP table
insert into GDP
values

('Belgium','2016','USD',475739588764.759)	,('Belgium','2017','USD',501522868356.441)	,('Belgium','2018','USD',543410654016.602)	,('Belgium','2019','USD',533254518108.234)	,('Belgium','2020','USD',515332499627.861)
,('Benin','2016','USD',11821065852.1271)	,('Benin','2017','USD',12701655845.9612)	,('Benin','2018','USD',14250987026.0533)	,('Benin','2019','USD',14391686309.033)	,('Benin','2020','USD',15651545208.8783)
,('Burkina Faso','2016','USD',12833363370.174)	,('Burkina Faso','2017','USD',14106956830.0857)	,('Burkina Faso','2018','USD',16059910870.6239)	,('Burkina Faso','2019','USD',15990803569.9961)	,('Burkina Faso','2020','USD',17369059295.2226)
,('Bangladesh','2016','USD',221415188000.475)	,('Bangladesh','2017','USD',249710922462.309)	,('Bangladesh','2018','USD',274038973437.275)	,('Bangladesh','2019','USD',302563398919.928)	,('Bangladesh','2020','USD',324239176765.053)
,('Bulgaria','2016','USD',53806894796.3801)	,('Bulgaria','2017','USD',58971520599.2509)	,('Bulgaria','2018','USD',66230155099.5775)	,('Bulgaria','2019','USD',68558815111.6199)	,('Bulgaria','2020','USD',69105101089.5531)
,('Estonia','2016','USD',24259552888.9717)	,('Estonia','2017','USD',26885077004.7802)	,('Estonia','2018','USD',30616184212.1592)	,('Estonia','2019','USD',31471100656.2431)	,('Estonia','2020','USD',31029968591.2779)
,('Ethiopia','2016','USD',74296618481.0882)	,('Ethiopia','2017','USD',81770791970.982)	,('Ethiopia','2018','USD',84269348327.3454)	,('Ethiopia','2019','USD',95912590628.1412)	,('Ethiopia','2020','USD',107645054311.876)
,('European Union','2016','USD',13883444699831.6)	,('European Union','2017','USD',14727943783142)	,('European Union','2018','USD',15956518442929.4)	,('European Union','2019','USD',15633997955351.1)	,('European Union','2020','USD',15192652399779.1)
,('Fragile and conflict affected situations','2016','USD',1639129985247.7)	,('Fragile and conflict affected situations','2017','USD',1676975053897.49)	,('Fragile and conflict affected situations','2018','USD',1796279850832.3)	,('Fragile and conflict affected situations','2019','USD',1915099191967.21)	,('Fragile and conflict affected situations','2020','USD',1734071057010.89)
,('Finland','2016','USD',240607907010.383)	,('Finland','2017','USD',255016517537.983)	,('Finland','2018','USD',275849574507.692)	,('Finland','2019','USD',268966065200)	,('Finland','2020','USD',271233883403.892)
,('Fiji','2016','USD',4930204229.72263)	,('Fiji','2017','USD',5353404422.08138)	,('Fiji','2018','USD',5581393120.62853)	,('Fiji','2019','USD',5496250694.31587)	,('Fiji','2020','USD',4376014755.57615)
,('France','2016','USD',2471285607081.72)	,('France','2017','USD',2588740901639.81)	,('France','2018','USD',2786502569559.77)	,('France','2019','USD',2715518274227.45)	,('France','2020','USD',2603004395901.95)
,('Faroe Islands','2016','USD',2738832687.13698)	,('Faroe Islands','2017','USD',2899226097.62377)	,('Faroe Islands','2018','USD',3051341335.9516)	,('Faroe Islands','2019','USD',3126293219.77989)	,('Faroe Islands','2020','USD',3126293219.77989)
,('Micronesia, Fed. Sts.','2016','USD',332265200)	,('Micronesia, Fed. Sts.','2017','USD',366666800)	,('Micronesia, Fed. Sts.','2018','USD',401932300)	,('Micronesia, Fed. Sts.','2019','USD',408060600)	,('Micronesia, Fed. Sts.','2020','USD',408060600)
,('Hong Kong SAR, China','2016','USD',320837638328.846)	,('Hong Kong SAR, China','2017','USD',341244161576.759)	,('Hong Kong SAR, China','2018','USD',361691522612.745)	,('Hong Kong SAR, China','2019','USD',363016373358.517)	,('Hong Kong SAR, China','2020','USD',346585881503.635)
,('Honduras','2016','USD',21717622071.3816)	,('Honduras','2017','USD',23136232229.6069)	,('Honduras','2018','USD',24067778953.842)	,('Honduras','2019','USD',25089976946.7736)	,('Honduras','2020','USD',23827840809.7014)
,('Heavily indebted poor countries (HIPC)','2016','USD',671572811964.428)	,('Heavily indebted poor countries (HIPC)','2017','USD',716948186184.384)	,('Heavily indebted poor countries (HIPC)','2018','USD',764543929212.911)	,('Heavily indebted poor countries (HIPC)','2019','USD',789537243675.88)	,('Heavily indebted poor countries (HIPC)','2020','USD',801469943817.275)
,('Croatia','2016','USD',51601147665.8089)	,('Croatia','2017','USD',55481644098.0495)	,('Croatia','2018','USD',61375222347.0256)	,('Croatia','2019','USD',60752588976.3175)	,('Croatia','2020','USD',55966581780.1688)
,('Haiti','2016','USD',13723267960.8434)	,('Haiti','2017','USD',14213814582.7938)	,('Haiti','2018','USD',15965670198.4548)	,('Haiti','2019','USD',14332163266.3977)	,('Haiti','2020','USD',13417997065.1099)
,('Hungary','2016','USD',128470534117.954)	,('Hungary','2017','USD',142961605733.026)	,('Hungary','2018','USD',160431092908.646)	,('Hungary','2019','USD',163503650313.081)	,('Hungary','2020','USD',155012927629.087)

