--learn more abt sp_add_schedule here: https://docs.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-add-schedule-transact-sql?view=sql-server-ver15

USE msdb ;  
GO  
  
--create a schedule
EXEC sp_add_schedule  
    @schedule_name = N'TuanDaily1' ,  
    @freq_type = 4,  --daily
    @freq_interval = 1,  
    @active_start_date = 20210924,
    @active_end_date = 20210926,
    @active_start_time = 151400 ;  
GO  
  
--attach the schedule to your job
EXEC sp_attach_schedule  
   @job_name = N'123',  
   @schedule_name = N'TuanDaily1' ;  
GO  

--if you want modify your schedule, use the following codes 
--for example, below I change the start time of a previously created job
USE msdb ;  
GO  
  
EXEC dbo.sp_update_schedule  
    @name = N'TuanDaily1',  
    @active_start_time = 152900 ; 
GO  